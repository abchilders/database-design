/*
Alex Childers
CS 325 - Fall 2018
Last modified: November 27, 2018
*/

prompt ====================================
prompt Deleting any current table contents.
prompt ==================================== 

delete from daycare_enrollment; 
delete from doggy_daycare; 
delete from boarding_enrollment; 
delete from boarding; 
delete from class_enrollment; 
delete from class_session_date; 
delete from pet_permitted_in_class; 
delete from class; 
delete from worker_providing_service; 
delete from service; 
delete from volunteer_handling_permissions; 
delete from volunteer; 
delete from employee_formal_qualifications; 
delete from employee; 
delete from worker_email_addr; 
delete from worker_phone_num; 
delete from worker; 
delete from dog; 
delete from cat; 
delete misc_pet_need; 
delete pet_diet_restriction; 
delete pet_medication_needed; 
delete pet_vaccine_received; 
delete pet; 
delete owner_email_addr; 
delete owner_phone_num; 
delete owner; 

prompt ===================================================
prompt Creating sequence to generate owner_ids for Owners.
prompt ===================================================
 
drop sequence owner_id_seq; 
create sequence owner_id_seq
start with 10; 

prompt ===============================================
prompt Creating sequence to generate pet_ids for Pets.
prompt ===============================================

drop sequence pet_id_seq; 
create sequence pet_id_seq
increment by 3
start with 100000;  

prompt ==========================
prompt Inserting rows into Owner.
prompt ========================== 

insert into owner
values
(owner_id_seq.nextval, 'Maya', 'Smith'); 

insert into owner
values
(owner_id_seq.nextval, 'Karen', 'Gearhardt');

insert into owner
values
(owner_id_seq.nextval, 'Lea', 'Krakowski');

insert into owner
values
(owner_id_seq.nextval, 'Kaisa', 'Tiryaki');

insert into owner
values
(owner_id_seq.nextval, 'Romulo', 'Santiago');

insert into owner
values
(owner_id_seq.nextval, 'Brecht', 'Zambrano');

insert into owner
values
(owner_id_seq.nextval, 'Maisie', 'Johanneson');

insert into owner
values
(owner_id_seq.nextval, 'Wanda', 'Taggart');

insert into owner
values
(owner_id_seq.nextval, 'Ernie', 'Smith');

insert into owner
values
(owner_id_seq.nextval, 'Rudolf', 'Siskind');

insert into owner
values
(owner_id_seq.nextval, 'Desmond', 'Boone');

prompt ===================================
prompt Inserting rows into Owner_phone_num. 
prompt ===================================

insert into owner_phone_num
values
(10, '5185550192'); 

insert into owner_phone_num
values
(11, '4105550133');

insert into owner_phone_num
values
(12, '4045550154');

insert into owner_phone_num
values
(13, '2075550181');

insert into owner_phone_num
values
(13, '5735550193'); 

insert into owner_phone_num
values
(13, '5735550120'); 

insert into owner_phone_num
values
(14, '5125550172');

insert into owner_phone_num
values
(15, '2255550101');

insert into owner_phone_num
values
(15, '5155550114');

insert into owner_phone_num
values
(16, '5125550192');

insert into owner_phone_num
values
(17, '7015550197');

insert into owner_phone_num
values
(18, '2085550124');

insert into owner_phone_num
values
(18, '4025550114');

insert into owner_phone_num
values
(19, '6175550188');

insert into owner_phone_num
values
(19, '9195550188');

insert into owner_phone_num
values
(20, '7755550128');

prompt =====================================
prompt Inserting rows into Owner_email_addr.
prompt =====================================

insert into owner_email_addr
values
(10, 'mayasmith@webmail.aa'); 

insert into owner_email_addr
values
(13, 'kaisa@kaisatiryaki.com'); 

insert into owner_email_addr
values
(13, 'ktiry12@webmail.aa');

insert into owner_email_addr
values
(11, 'gearhardtka@coldmail.net');

insert into owner_email_addr
values
(14, 'romsant1@csumed.edu');

insert into owner_email_addr
values
(14, 'rsantiago@coldmail.net');

insert into owner_email_addr
values
(15, 'therealmothman@webmail.aa');

insert into owner_email_addr
values
(16, 'maisiemae@coldmail.net');

insert into owner_email_addr
values
(18, 'ernie@erniesmith.net');

insert into owner_email_addr
values
(18, 'oovoojaver@coldmail.net');

insert into owner_email_addr
values
(20, 'dboone@csumed.edu');

prompt Inserting rows into Pet. 

insert into pet(pet_id, pet_name, sex, is_spayed_neutered, pet_type, owner_id)
values
(10, 'Kiwi', 'f', 'y', 'cat', '

prompt Inserting rows into Pet_vaccine_received.

prompt Inserting rows into Pet_medication_needed. 

prompt Inserting rows into Pet_diet_restriction.

prompt Inserting rows into Misc_pet_need. 

prompt Inserting rows into Cat. 

prompt Inserting rows into Dog. 

prompt Inserting rows into Worker. 

prompt Inserting rows into Worker_phone_num. 

prompt Inserting rows into Worker_email_addr. 

prompt Inserting rows into Employee. 

prompt Inserting rows into Employee_formal_qualifications. 

prompt Inserting rows into Volunteer. 

prompt Inserting rows into Volunteer_handling_permissions. 

prompt Inserting rows into Service. 

prompt Inserting rows into Worker_providing_service. 

prompt Inserting rows into Class. 

prompt Inserting rows into Pet_permitted_in_class. 

prompt Inserting rows into Class_session_date. 

prompt Inserting rows into Class_enrollment. 

prompt Inserting rows into Boarding. 

prompt Inserting rows into Boarding_enrollment. 

prompt Inserting rows into Doggy_daycare. 

prompt Inserting rows into Daycare_enrollment. 
