/*
Alex Childers
CS 325 - Fall 2018
Last modified: November 26, 2018
*/

-- Delete all current contents of tables. 
delete from daycare_enrollment; 
delete from doggy_daycare; 
delete from boarding_enrollment; 
delete from boarding; 
delete from class_enrollment; 
delete from class_session_date; 
delete from pet_permitted_in_class; 
delete from class; 
delete from worker_providing_service; 
delete from service; 
delete from volunteer_handling_permissions; 
delete from volunteer; 
delete from employee_formal_qualifications; 
delete from employee; 
delete from worker_email_addr; 
delete from worker_phone_num; 
delete from worker; 
delete from dog; 
delete from cat; 
delete misc_pet_need; 
delete pet_diet_restriction; 
delete pet_medication_needed; 
delete pet_vaccine_received; 
delete pet; 
delete owner_email_addr; 
delete owner_phone_num; 
delete owner; 

prompt Inserting rows into Owner. 

prompt Inserting rows into Owner_phone_num. 

prompt Inserting rows into Owner_email_addr. 

prompt Inserting rows into Pet. 

prompt Inserting rows into Pet_vaccine_received.

prompt Inserting rows into Pet_medication_needed. 

prompt Inserting rows into Pet_diet_restriction.

prompt Inserting rows into Misc_pet_need. 

prompt Inserting rows into Cat. 

prompt Inserting rows into Dog. 

prompt Inserting rows into Worker. 

prompt Inserting rows into Worker_phone_num. 

prompt Inserting rows into Worker_email_addr. 

prompt Inserting rows into Employee. 

prompt Inserting rows into Employee_formal_qualifications. 

prompt Inserting rows into Volunteer. 

prompt Inserting rows into Volunteer_handling_permissions. 

prompt Inserting rows into Service. 

prompt Inserting rows into Worker_providing_service. 

prompt Inserting rows into Class. 

prompt Inserting rows into Pet_permitted_in_class. 

prompt Inserting rows into Class_session_date. 

prompt Inserting rows into Class_enrollment. 

prompt Inserting rows into Boarding. 

prompt Inserting rows into Boarding_enrollment. 

prompt Inserting rows into Doggy_daycare. 

prompt Inserting rows into Daycare_enrollment. 
