/* Alex Childers
   CS 325 - Homework 10 - Problem 5
   Last modified: November 30, 2018
*/

@ movies-pop

spool 325hw10-out.txt

prompt =======================
prompt Homework 10 Problem 5
prompt =======================

prompt ************
prompt problem 5-2

/* Project, for each rental, the renting client's last name, and the rented 
   video's format, displaying the results in order of client's last name, and
   in secondary order by rented video's format. 
*/

select 	client_lname, vid_format
from 	client c
		join rental r on c.client_num = r.client_num
		join video v on r.vid_id = v.vid_id
order by client_lname, vid_format; 

prompt ************
prompt problem 5-3

/* Write a query that will project, *just for not-yet-returned rentals

*/

prompt ************
prompt problem 5-4

prompt ************
prompt problem 5-5

prompt ************
prompt problem 5-6

prompt ************
prompt problem 5-7

prompt ************
prompt problem 5-8

prompt ************
prompt problem 5-9

prompt ===================
prompt 5-9 part a 

prompt ===================
prompt 5-9 part b

prompt ===================
prompt 5-9 part c

prompt ===================
prompt 5-9 part d

prompt ************
prompt problem 5-10

prompt ************
prompt problem 5-11

prompt ************
prompt problem 5-12

prompt ************
prompt problem 5-13

prompt ************
prompt problem 5-14

spool off 
