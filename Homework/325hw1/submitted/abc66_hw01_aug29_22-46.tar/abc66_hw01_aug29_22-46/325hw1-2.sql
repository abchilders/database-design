/* Alex Childers
   325 HW 1 - part 2
   Last modified 08/29/2018
*/

spool 325hw1-out.txt

select *
from familyCats;

spool off
